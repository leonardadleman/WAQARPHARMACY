<?php
session_start();
$dbHost = 'localhost';
$dbName = 'waqaegvl_mydb';
$dbUsername = 'waqaegvl_mydb';
$dbPassword = 'Waqarkhan123!';
$dbc=mysqli_connect($dbHost,$dbUsername,$dbPassword,$dbName); 
?>